<!DOCTYPE html>
<html>
  <div id="sidebar" class="sidebar py-3">
    <div
      class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family"
    >
      MAIN
    </div>
    <ul class="sidebar-menu list-unstyled">
      <li class="sidebar-list-item">
        <a href="dashboard.php" class="sidebar-link text-muted"
          ><i class="o-home-1 mr-3 text-gray"></i><span>Dashboard</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a href="charts.php" class="sidebar-link text-muted"
          ><i class="o-sales-up-1 mr-3 text-gray"></i><span>Statistics</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a href="showstatus.php" class="sidebar-link text-muted"
          ><i class="o-table-content-1 mr-3 text-gray"></i><span>Bins</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a
          href="#"
          data-toggle="collapse"
          data-target="#pagesTrans"
          aria-expanded="false"
          aria-controls="pagesTrans"
          class="sidebar-link text-muted"
          ><i class="o-survey-1 mr-3 text-gray"></i><span>Transactions</span></a
        >
        <div id="pagesTrans" class="collapse">
          <ul
            class="sidebar-menu list-unstyled border-left border-primary border-thick"
          >
            <li class="sidebar-list-item">
              <a
                href="viewtransaction.php"
                class="sidebar-link text-muted pl-lg-5"
                >View Transactions</a
              >
            </li>
            <li class="sidebar-list-item">
              <a
                href="addtransaction.php"
                class="sidebar-link text-muted pl-lg-5"
                >Add Transaction</a
              >
            </li>
          </ul>
        </div>
      </li>
      <li class="sidebar-list-item">
        <a href="viewcollectionpoints.php" class="sidebar-link text-muted"
          ><i class="o-paperwork-1 mr-3 text-gray"></i
          ><span>Collection Points</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a href="viewfeedbacks.php" class="sidebar-link text-muted"
          ><i class="o-wireframe-1 mr-3 text-gray"></i><span>Feedback</span></a
        >
      </li>
    </ul>
    <div
      class="text-gray-400 text-uppercase px-3 px-lg-4 py-4 font-weight-bold small headings-font-family"
    >
      USER
    </div>
    <ul class="sidebar-menu list-unstyled">
      <li class="sidebar-list-item">
        <a href="#" class="sidebar-link text-muted"
          ><i class="o-database-1 mr-3 text-gray"></i><span>Account</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a href="#" class="sidebar-link text-muted"
          ><i class="o-imac-screen-1 mr-3 text-gray"></i
          ><span>Add User</span></a
        >
      </li>
      <li class="sidebar-list-item">
        <a href="logout.php" class="sidebar-link text-muted"
          ><i class="o-exit-1 mr-3 text-gray"></i><span>Logout</span></a
        >
      </li>
    </ul>
  </div>
</html>
