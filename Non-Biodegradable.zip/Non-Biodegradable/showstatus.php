<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Bubbly - Boootstrap 4 Admin template by Bootstrapious.com</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="all,follow">
    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <!-- Google fonts - Popppins for copy-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,800">
    <!-- orion icons-->
    <link rel="stylesheet" href="css/orionicons.css">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.png?3">
    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script><![endif]-->
  </head>
  <body>
    <!-- navbar-->
    <?php include("header.php"); ?>  
    <div class="d-flex align-items-stretch"> <!-- keep coding inside this tag. it stretches-->
      <!-- sidebar-->
      <?php include("sidebar.php"); ?> 
      <div class="page-holder w-100 d-flex flex-wrap">
        <div class="container-fluid px-xl-5">
          <section class="py-5">
            <div class="row">
              
              <div class="col-lg-12 mb-4">
                <section>
            <div class="row">
              <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                <div
                  class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between"
                >
                  <div class="flex-grow-1 d-flex align-items-center">
                    <div class="dot mr-3 bg-green"></div>
                    <div class="text">
                      <h5 class="mb-0">Paper</h5>
                      <span class="text-gray">70%</span>
                    </div>
                  </div>
                  <div class="col-sm-8">
                    <canvas id="pieChartHome1"></canvas>
                  </div>
                </div>
              </div>
              <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                <div
                  class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between"
                >
                  <div class="flex-grow-1 d-flex align-items-center">
                    <div class="dot mr-3 bg-blue"></div>
                    <div class="text">
                      <h5 class="mb-0">Metal</h5>
                      <span class="text-gray">90%</span>
                    </div>
                  </div>
                  <div class="col-sm-8">
                    <canvas id="pieChartHome2"></canvas>
                  </div>
                </div>
              </div>
              <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                <div
                  class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between"
                >
                  <div class="flex-grow-1 d-flex align-items-center">
                    <div class="dot mr-3 bg-violet"></div>
                    <div class="text">
                      <h5 class="mb-0">Glass</h5>
                      <span class="text-gray">87%</span>
                    </div>
                  </div>
                  <div class="col-sm-8">
                    <canvas id="pieChartHome3"></canvas>
                  </div>
                </div>
              </div>
              <div class="col-xl-3 col-lg-6 mb-4 mb-xl-0">
                <div
                  class="bg-white shadow roundy p-4 h-100 d-flex align-items-center justify-content-between"
                >
                  <div class="flex-grow-1 d-flex align-items-center">
                    <div class="dot mr-3 bg-red"></div>
                    <div class="text">
                      <h5 class="mb-0">Plastic</h5>
                      <span class="text-gray">123</span>
                    </div>
                  </div>
                  <div class="col-sm-8">
                    <canvas id="pieChartHome4"></canvas>
                  </div>
                </div>
              </div>
            </div>
          </section>
              </div>
              
              <div class="col-lg-12 mb-5">
                <div class="card">
                  <div class="card-header">
                    <h6 class="text-uppercase mb-0">List Of Companies</h6>
                  </div>
                  <div class="card-body">                           
                    <table class="table table-striped card-text">
                      <thead>
                        <tr>
                          <th>State</th>
                          <th>City</th>
                          <th>Branch</th>
                          <th>Contact No.</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row" rowspan="3" style="text-align: center; vertical-align: middle">Fabric</th>
                          <td>Sapura Energy Sdn. Bhd.</td>
                          <td>No. 1 & 3, <br/>Jalan KF4,Kota Fesyen – MITC, <br/>Hang Tuah Jaya, <br/>75450 Ayer Keroh, Melaka</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@sapuraenergy</td>
                        </tr>
                        <tr>
                          <td>CWM Group Sdn Bhd</td>
                          <td>Lot G1, G2 & G3, <br/>Wisma Air, <br/>Jalan Hang Tuah, <br/>75300 Melaka</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@CWM</td>
                        </tr>
                        <tr>
                          <td>Inciner8 Limited</td>
                          <td>JC 526 & JC 527 Ground Floor, <br/>Jalan Bestari 5, <br/>Bandar Jasin Bestari, Section 2, <br/>77200 Jasin, Melaka</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@inciner8</td>
                        </tr>
                        <tr>
                          <th scope="row" rowspan="5" style="text-align: center; vertical-align: middle">Plastic</th>
                          <td>DILO Armaturen und Anlagen GmbH</td>
                          <td>No. 1 & 3, <br/>Jalan Pandan Prima 2, <br/>Dataran Prima Ampang, <br/>68000 Ampang, Selangor</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@DILO</td>
                        </tr>
                        <tr>
                          <td>GHD Pty Ltd</td>
                          <td>A-G-01 & A-1-01, Block A, <br/>No. 2, Jalan PJU 1A/7A, <br/>Ara Damansara, PJU 1A, <br/>47301 Petaling Jaya, Selangor</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@GHD</td>
                        </tr>
                        <tr>
                          <td>Crudesco Sdn Bhd</td>
                          <td>No. 2 & 4, <br/>Jalan 6C/7, <br/>43650 Bandar Baru Bangi, Selangor</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@crudeso</td>
                        </tr>
                        <tr>
                          <td>Cycle Trend Industries</td>
                          <td>Suite 0-55 & 0-56, <br/>4812 Central Business District Perdana 2, <br/>Jalan Perdana, Cyber 12, <br/>63000 Cyberjaya, Selangor</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@cycle_trend</td>
                        </tr>
                        <tr>
                          <td>ESP (International) Ltd.</td>
                          <td>Lot 336, <br/>Kompleks Majlis Agama Islam Selangor, <br/>Section 23, Jalan Kapar, <br/>41400 Klang, Selangor</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@ESPwaste</td>
                        </tr>
                        <tr>
                          <th scope="row" rowspan="2" style="text-align: center; vertical-align: middle">Chemical</th>
                          <td>STREAM Environment Sdn. Bhd.</td>
                          <td>No. 71 & 73, <br/>Jalan Taman Selat, <br/>Off Jalan Bagan Luar, P.O. Box 303, <br/>12720 Butterworth, Pulau Pinang</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@STREAMalaysia</td>
                        </tr><tr>
                          <td>Chemical Waste Management Sdn. Bhd.</td>
                          <td>Ground Floor, <br/>Wisma Great Eastern, <br/>Light Street, Peti Surat 1204, <br/>10200 Georgetown, Pulau Pinang</td>
                          <td>Tel: 06-232 0986<br/>Fax: 06-232 6561<br/>@CWM</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
          </section>
        </div>
        <!-- footer-->
        <?php include("footer.php"); ?>
      </div>
    </div>
     <!-- JavaScript files-->
    <?php include("javascript.php"); ?>
  </body>
</html>